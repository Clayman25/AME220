var easingsList = [
"swing",
"easeInQuad",
"easeOutQuad",
"easeInOutQuad",
"easeInCubic",
"easeOutCubic",
"easeInOutCubic",
"easeInQuart",
"easeOutQuart",
"easeInOutQuart",
"easeInQuint",
"easeOutQuint",
"easeInOutQuint",
"easeInSine",
"easeOutSine",
"easeInOutSine",
"easeInExpo",
"easeOutExpo",
"easeInOutExpo",
"easeInCirc",
"easeOutCirc",
"easeInOutCirc",
"easeInElastic",
"easeOutElastic",
"easeInOutElastic",
"easeInBack",
"easeOutBack",
"easeInOutBack",
"easeInBounce",
"easeOutBounce"
];

  var moveRight = function(){
  var n = 0;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxRight(n, e, d);

  var n = 1;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxRight(n, e, d);
  
  var n = 2;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxRight(n, e, d);

  var n = 3;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxRight(n, e, d);
  
  var n = 4;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxRight(n, e, d);
    
  var n = 5;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxRight(n, e, d);
  
  var n = 6;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxRight(n, e, d);
      
  var n = 7;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxRight(n, e, d);
  
  var n = 8;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxRight(n, e, d);

  var n = 9;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxRight(n, e, d);
  
  var n = 10;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxRight(n, e, d);

  var n = 11;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxRight(n, e, d);
  
  var n = 12;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxRight(n, e, d);

  var n = 13;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxRight(n, e, d);
  
  var n = 14;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxRight(n, e, d);
      
  var n = 15;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxRight(n, e, d);
  
  var n = 16;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxRight(n, e, d);

  var n = 17;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxRight(n, e, d);
  
  var n = 18;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxRight(n, e, d);
    
  var n = 19;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxRight(n, e, d);
  
  var n = 20;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxRight(n, e, d);
      
  var n = 21;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxRight(n, e, d);
  
  var n = 22;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxRight(n, e, d);

  var n = 23;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxRight(n, e, d);
  
  var n = 24;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxRight(n, e, d);

  var n = 25;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxRight(n, e, d);
  
  var n = 26;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxRight(n, e, d);

  var n = 27;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxRight(n, e, d);
  
  var n = 28;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxRight(n, e, d);
      
  var n = 29;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxRight(n, e, d);
};

var moveLeft = function(){
  var n = 0;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxLeft(n, e, d);

  var n = 1;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxLeft(n, e, d);
  
  var n = 2;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxLeft(n, e, d);

  var n = 3;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxLeft(n, e, d);
  
  var n = 4;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxLeft(n, e, d);
    
  var n = 5;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxLeft(n, e, d);
  
  var n = 6;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxLeft(n, e, d);
      
  var n = 7;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxLeft(n, e, d);
  
  var n = 8;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxLeft(n, e, d);

  var n = 9;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxLeft(n, e, d);
  
  var n = 10;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxLeft(n, e, d);

  var n = 11;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxLeft(n, e, d);
  
  var n = 12;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxLeft(n, e, d);

  var n = 13;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxLeft(n, e, d);
  
  var n = 14;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxLeft(n, e, d);
      
  var n = 15;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxLeft(n, e, d);
  
  var n = 16;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxLeft(n, e, d);

  var n = 17;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxLeft(n, e, d);
  
  var n = 18;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxLeft(n, e, d);
    
  var n = 19;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxLeft(n, e, d);
  
  var n = 20;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxLeft(n, e, d);
      
  var n = 21;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxLeft(n, e, d);
  
  var n = 22;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxLeft(n, e, d);

  var n = 23;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxLeft(n, e, d);
  
  var n = 24;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxLeft(n, e, d);

  var n = 25;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxLeft(n, e, d);
  
  var n = 26;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxLeft(n, e, d);

  var n = 27;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxLeft(n, e, d);
  
  var n = 28;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxLeft(n, e, d);
      
  var n = 29;
  var e = easingsList[n];
  var d = parseInt($("#delay").val());
  moveBoxLeft(n, e, d);
};

var moveBoxRight= function(n, easing, duration)
{
  var id = "#button" + n.toString();
  var pageWidth = $("body").width();
  var boxWidth = 150;
  $(id).animate({"margin-left":pageWidth-boxWidth + "px"}, duration, easing); 
}

var moveBoxLeft= function(n, easing, duration)
{
  var id = "#button" + n.toString();
  var pageWidth = $("body").width();
  var boxWidth = 150;
  $(id).animate({"margin-left" : "0px"}, duration, easing); 
}